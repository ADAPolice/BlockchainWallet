Sample configuration files for:
```
SystemD: pivxd.service
Upstart: pivxd.conf
OpenRC:  pivxd.openrc
         pivxd.openrcconf
CentOS:  pivxd.init
macOS:    org.pivx.pivxd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
